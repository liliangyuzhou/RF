str1="hello,world"
str2="hello,RF"
num=200
bool=True	
DICT__dicta={"key":"value","key1":"value1"}
LIST__lista=[1,2,35,6]
DICT__data1={"mobilephone":"18211562134","pwd":"1234567"}
