class exceldo(object):

    ROBOT_LIBRARY_VERSION = 1.0

    def __init__(self, filename=None, sheetname=None):
        pass
    def get_cases(self):
       pass